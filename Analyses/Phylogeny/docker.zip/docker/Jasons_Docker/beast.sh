#!/bin/bash

# Run BEAST with 4 threads and the specified XML file
beast -threads 4 beast.xml